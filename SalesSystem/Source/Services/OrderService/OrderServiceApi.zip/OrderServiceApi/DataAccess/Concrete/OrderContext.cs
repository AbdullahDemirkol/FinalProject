﻿using Microsoft.EntityFrameworkCore;
using OrderService.Infrastructure.EntityConfigurations;
using OrderServiceApi.Entity.Concrete.Buyer;
using OrderServiceApi.Entity.Concrete.Enum;
using OrderServiceApi.Entity.Concrete.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.DataAccess.Concrete
{

    public class OrderContext : DbContext
    {
        public const string DEFAULT_SCHEMA = "ordering";
        public OrderContext(DbContextOptions<OrderContext> options) :
            base(options)
        { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.ApplyConfiguration(new OrderEntityConfiguration());
            //modelBuilder.ApplyConfiguration(new BuyerEntityConfiguration());
            //modelBuilder.ApplyConfiguration(new CardTypeEntityConfiguration());
            //modelBuilder.ApplyConfiguration(new OrderItemEntityConfiguration());
            //modelBuilder.ApplyConfiguration(new OrderStatusEntityConfiguration());
            //modelBuilder.ApplyConfiguration(new PaymentMethodEntityConfiguration());
            base.OnModelCreating(modelBuilder);
        }
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseNpgsql("Host=localhost;Database=CatalogDatabase;Username=postgres;Password=1234");
        //}
        public DbSet<Order> Orders{ get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<PaymentMethod> PaymentMethods{ get; set; }
        public DbSet<Buyer> Buyers { get; set; }
        public DbSet<CardType> CardTypes { get; set; }
        public DbSet<OrderStatus> OrderStatuses{ get; set; }

    }
}

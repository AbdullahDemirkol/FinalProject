﻿using OrderServiceApi.DataAccess.Abstract;
using OrderServiceApi.Entity.Concrete.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace OrderServiceApi.DataAccess.Concrete
{
    public class OrderRepository : GenericRepository<Order>, IOrderRepository
    {
        private readonly OrderContext _orderContext;

        public OrderRepository(OrderContext orderContext) : base(orderContext)
        {
            _orderContext = orderContext;
        }
        public override async Task<Order> GetByIdAsync(Guid id, params Expression<Func<Order, object>>[] includes)
        {
            var entity = await base.GetByIdAsync(id, includes);
            if (entity == null)
            {
                entity = _orderContext.Orders.Local.FirstOrDefault(i => i.Id == id);
            }
            return entity;
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OrderServiceApi.DataAccess.Concrete;
using OrderServiceApi.Entity.Concrete.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderService.Infrastructure.EntityConfigurations
{
    internal class CardTypeEntityConfiguration : IEntityTypeConfiguration<CardType>
    {
        public void Configure(EntityTypeBuilder<CardType> builder)
        {
            builder.ToTable("cardtypes", OrderContext.DEFAULT_SCHEMA);
            builder.HasKey(ct => ct.Id);
            builder.Property(i => i.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(ct => ct.Id)
                .HasDefaultValue(1)
                .ValueGeneratedOnAdd()
                .IsRequired(); 
            builder.Property(ct => ct.Name)
                 .HasMaxLength(200)
                 .IsRequired();
        }
    }
}

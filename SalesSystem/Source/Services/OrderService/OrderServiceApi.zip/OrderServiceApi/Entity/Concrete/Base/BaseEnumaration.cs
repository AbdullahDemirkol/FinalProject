﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.Entity.Concrete.Base
{
    public class BaseEnumaration
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public BaseEnumaration(int id, string name)
        {
        }
    }
}

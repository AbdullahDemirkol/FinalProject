﻿using EventBus.Base.Entity.Concrete;
using OrderServiceApi.Entity.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.Entity.Concrete.Base
{
    public class BaseEntity:IEntity
    {
        public virtual Guid Id { get; set; }
        public DateTime CreateDate { get; set; }

        private List<IntegrationEvent> domainEvents;
        public IReadOnlyCollection<IntegrationEvent> DomainEvents => domainEvents.AsReadOnly();

        public void AddDomainEvent(IntegrationEvent domainEvent)
        {
            domainEvents = domainEvents ?? new List<IntegrationEvent>();
            domainEvents.Add(domainEvent);
        }
        public void RemoveDomainEvent(IntegrationEvent domainEvent)
        {
            domainEvents?.Remove(domainEvent);
        }
        public void ClearDomainEvent()
        {
            domainEvents?.Clear();
        }
    }
}

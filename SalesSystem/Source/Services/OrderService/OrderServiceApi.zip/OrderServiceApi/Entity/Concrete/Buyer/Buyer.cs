﻿using OrderServiceApi.Entity.Abstract;
using OrderServiceApi.Entity.Concrete.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.Entity.Concrete.Buyer
{

    public class Buyer : BaseEntity,IEntity
    {
        public string Name { get; set; }

        private List<PaymentMethod> _paymentMethods;
        public IEnumerable<PaymentMethod> PaymentMethods() => _paymentMethods.AsReadOnly();
        protected Buyer()
        {
            _paymentMethods = new List<PaymentMethod>();
        }

        public Buyer(string name) : this()
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
        }
        public PaymentMethod VerifyOrAddPaymentMethod(int cardTypeId, string alias, string cardNumber, string securityNumber, string cardHolderName, DateTime expiration, Guid orderId)
        {
            var existingPayment = _paymentMethods.SingleOrDefault(p => p.IsEqualPaymentMethod(cardTypeId, cardNumber, expiration));
            return existingPayment;

        }
    }
}

﻿using OrderServiceApi.Entity.Concrete.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.Entity.Concrete.Enum
{
    public class OrderStatus: BaseEnumaration
    {
        public OrderStatus(int id, string name):base(id,name)
        {
            Id = id;
            Name = name;
        }
        public static OrderStatus Submitted = new(1, nameof(Submitted).ToLowerInvariant());
        public static OrderStatus DoğrulamaBekleniyor = new(2, nameof(DoğrulamaBekleniyor).ToLowerInvariant());
        public static OrderStatus StokOnaylandı = new(3, nameof(StokOnaylandı).ToLowerInvariant());
        public static OrderStatus Paid = new(4, nameof(Paid).ToLowerInvariant());
        public static OrderStatus Gönderildi = new(5, nameof(Gönderildi).ToLowerInvariant());
        public static OrderStatus İptalEdildi = new(6, nameof(İptalEdildi).ToLowerInvariant());

        public static IEnumerable<OrderStatus> List()
        {
            return new[] { Submitted, DoğrulamaBekleniyor, StokOnaylandı, Paid, Gönderildi, İptalEdildi };
        }
        public static OrderStatus FromName(string name)
        {
            var state = List().SingleOrDefault(p => p.Name == name);
            return state;
        }
        public static OrderStatus FromId(int id)
        {
            var state = List().SingleOrDefault(p => p.Id == id);
            return state;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.Entity.Concrete
{
    public class CustomerBasket
    {
        public string UserName { get; set; }
        public List<BasketItem> Items { get; set; }

        public CustomerBasket(string userName)
        {
            UserName = userName;
            Items = new List<BasketItem>();
        }
    }
}

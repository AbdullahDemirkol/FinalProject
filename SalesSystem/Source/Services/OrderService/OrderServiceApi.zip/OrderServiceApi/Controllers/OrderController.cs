﻿using EventBus.Base.EventBus.Abstract;
using Microsoft.AspNetCore.Mvc;
using OrderServiceApi.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        IEventBus _eventBus;

        public OrderController(IEventBus eventBus)
        {
            _eventBus = eventBus;
        }

        [HttpGet("{id}")]
        public IActionResult GetOrderDetailsById(Guid orderId)
        {
            _eventBus.Publish(new GetOrderDetailsQueryModel(orderId));
            return Ok();
        }
    }
}

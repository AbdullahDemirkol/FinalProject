﻿using EventBus.Base.Entity.Abstract;
using MediatR;
using Microsoft.Extensions.Logging;
using OrderService.Application.Features.Commands;
using OrderServiceApiii.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApiii.IntegrationEvents.EventHandlers
{

    public class OrderCreatedIntegrationEventHandler : IIntegrationEventHandler<OrderCreatedIntegrationEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<OrderCreatedIntegrationEventHandler> _logger;

        public OrderCreatedIntegrationEventHandler(IMediator mediator, ILogger<OrderCreatedIntegrationEventHandler> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        public async Task Handle(OrderCreatedIntegrationEvent integrationEvent)
        {
            _logger.LogInformation("Handling integration event:{IntegrationEventId} at {AppName}-({IntegrationEvent})", integrationEvent.Id, typeof(Startup).Namespace, integrationEvent);
            var createOrderCommand = new CreateOrderCommand(integrationEvent.Basket.Items, integrationEvent.UserId, integrationEvent.UserName, integrationEvent.City, integrationEvent.Street, integrationEvent.State, integrationEvent.Country, integrationEvent.ZipCode, integrationEvent.CardNumber, integrationEvent.CardHolderName, integrationEvent.CardExpiration, integrationEvent.CardSecurityNumber, integrationEvent.CardTypeId);
            await _mediator.Send(createOrderCommand);


        }
    }
}

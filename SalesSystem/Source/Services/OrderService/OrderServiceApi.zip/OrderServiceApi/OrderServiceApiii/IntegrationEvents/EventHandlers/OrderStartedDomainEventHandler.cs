﻿using MediatR;
using OrderServiceApiii.DataAccess.Repositories.Abstract;
using OrderServiceApiii.Entity.Concrete.Buyer;
using OrderServiceApiii.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OrderServiceApiii.IntegrationEvents.EventHandlers
{
    public class OrderStartedDomainEventHandler : INotificationHandler<OrderStartedDomainEvent>
    {
        private readonly IBuyerRepository _buyerRepository;

        public OrderStartedDomainEventHandler(IBuyerRepository buyerRepository)
        {
            _buyerRepository = buyerRepository;
        }

        public async Task Handle(OrderStartedDomainEvent orderStartedDomainEvent, CancellationToken cancellationToken)
        {
            var cardTypeId = (orderStartedDomainEvent.CardTypeId != 0) ? orderStartedDomainEvent.CardTypeId : 1;
            var buyer = await _buyerRepository.GetSingleAsync(i => i.Name == orderStartedDomainEvent.UserName, i => i.PaymentMethods());
            bool buyerOriginallyExisted = buyer != null;
            if (!buyerOriginallyExisted)
            {
                buyer = new Buyer(orderStartedDomainEvent.UserName);
            }
            buyer.VerifyOrAddPaymentMethod(cardTypeId, $"Payment Method on {DateTime.UtcNow}", orderStartedDomainEvent.CardNumber, orderStartedDomainEvent.CardSecurityNumber, orderStartedDomainEvent.CardHolderName, orderStartedDomainEvent.CardExpiration, orderStartedDomainEvent.Order.Id);
            var buyerUpdated = buyerOriginallyExisted ? _buyerRepository.Update(buyer) : await _buyerRepository.AddAsync(buyer);
            await _buyerRepository.UnitOfWork.SaveEntityAsync(cancellationToken);
        }
    }
}

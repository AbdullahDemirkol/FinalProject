﻿using MediatR;
using OrderService.Application.Features.Queries.ViewModels;
using OrderServiceApiii.Entity.Concrete.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderService.Application.Features.Queries.GetOrderDetailById
{
    public class GetOrderDetailsQuery:IRequest</*OrderDetailViewModel*/ Order>
    {
        public Guid OrderId { get; set; }

        public GetOrderDetailsQuery(Guid orderId)
        {
            OrderId = orderId;
        }
    }
}

﻿using OrderServiceApiii.DataAccess;
using OrderServiceApiii.Entity.Concrete.Helper.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApiii.Extensions.Migration.MigrationSeeds
{
    public class OrderContextSeed
    {

        public static async Task SeedAsync(OrderContext orderContext)
        {
            if (orderContext.OrderStatus.Count() == 0)
            {
                orderContext.OrderStatus.AddRange(GetDefaultOrderStatus());
                await orderContext.SaveChangesAsync();
            }

            if (orderContext.CardTypes.Count() == 0)
            {
                orderContext.CardTypes.AddRange(GetDefaultCardTypes());
                await orderContext.SaveChangesAsync();
            }

        }

        private static IEnumerable<CardType> GetDefaultCardTypes()
        {
            IEnumerable<CardType> cardTypes = CardType.List();
            return cardTypes;
        }

        private static IEnumerable<OrderStatus> GetDefaultOrderStatus()
        {
            IEnumerable<OrderStatus> orderStatuses = OrderStatus.List();
            return orderStatuses;
        }
    }

}

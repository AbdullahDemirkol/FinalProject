﻿using MediatR;
using OrderServiceApiii.DataAccess;
using OrderServiceApiii.Entity.Concrete.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApiii.Extensions.BussExtension
{
    public static class BussExtensions
    {
        public static async Task DispatchDomainEventsAsnyc(this IMediator mediator, OrderContext orderContext)
        {
            var domainEntities = orderContext.ChangeTracker
                .Entries<BaseEntity>()
                .Where(p => p.Entity.DomainEvents != null && p.Entity.DomainEvents.Any());
            var domainEvents = domainEntities
                .SelectMany(p => p.Entity.DomainEvents)
                .ToList();
            domainEntities.ToList()
                .ForEach(entity => entity.Entity.ClearDomainEvent());
            foreach (var domainEvent in domainEvents)
            {
                await mediator.Publish(domainEvent);
            }
        }
    }
}

﻿using OrderServiceApiii.Entity.Concrete.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApiii.DataAccess.Repositories.Abstract
{
    public interface IOrderRepository : IGenericRepository<Order>
    {
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OrderServiceApiii.Entity.Concrete.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderServiceApiii.DataAccess.EntityConfigurations
{
    internal class OrderItemEntityConfiguration : IEntityTypeConfiguration<OrderItem>
    {
        public void Configure(EntityTypeBuilder<OrderItem> builder)
        {
            builder.ToTable("orderItems", OrderContext.DEFAULT_SCHEMA);
            builder.HasKey(o => o.Id);
            builder.Ignore(b => b.DomainEvents);
            builder.Property(o => o.Id).ValueGeneratedOnAdd();
            builder.Property<int>("OrderId").IsRequired();
        }
    }
}

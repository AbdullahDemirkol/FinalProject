﻿using Microsoft.EntityFrameworkCore;
using OrderServiceApiii.DataAccess.Repositories.Abstract;
using OrderServiceApiii.Entity.Abstract;
using OrderServiceApiii.Entity.Concrete.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace OrderServiceApiii.DataAccess.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : BaseEntity
    {
        private readonly OrderContext _orderContext;

        public GenericRepository(OrderContext orderContext)
        {
            _orderContext = orderContext ?? throw new ArgumentNullException(nameof(orderContext));
        }

        public IUnitOfWork UnitOfWork { get; }

        public async Task<T> AddAsync(T entity)
        {
            await _orderContext.AddAsync(entity);
            return entity;
        }

        public virtual async Task<List<T>> Get(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> queryable = _orderContext.Set<T>();
            foreach (Expression<Func<T, object>> include in includes)
            {

                queryable = queryable.Include(include);
            }
            if (filter != null)
            {
                queryable = queryable.Where(filter);
            }
            if (orderBy != null)
            {
                queryable = orderBy(queryable);
            }
            return await queryable.ToListAsync();
        }

        public virtual Task<List<T>> Get(Expression<Func<T, bool>> filter = null, params Expression<Func<T, object>>[] includes)
        {
            return Get(filter, null, includes);
        }

        public virtual async Task<List<T>> GetAll()
        {
            return await _orderContext.Set<T>().ToListAsync();
        }

        public virtual async Task<T> GetById(Guid id)
        {
            return await _orderContext.Set<T>().FindAsync(id);
        }

        public virtual async Task<T> GetByIdAsync(Guid id, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> queryable = _orderContext.Set<T>();
            foreach (Expression<Func<T, object>> include in includes)
            {
                queryable = queryable.Include(include);
            }
            return await queryable.FirstOrDefaultAsync(i => i.Id == id);

        }

        public virtual async Task<T> GetSingleAsync(Expression<Func<T, bool>> expression, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> queryable = _orderContext.Set<T>();
            foreach (Expression<Func<T, object>> include in includes)
            {
                queryable = queryable.Include(include);
            }
            return await queryable.Where(expression).SingleOrDefaultAsync();
        }

        public virtual T Update(T entity)
        {
            _orderContext.Set<T>().Update(entity);
            return entity;
        }
    }
}

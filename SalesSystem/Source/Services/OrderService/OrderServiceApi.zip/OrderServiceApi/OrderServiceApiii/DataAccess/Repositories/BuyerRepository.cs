﻿using OrderServiceApiii.DataAccess.Repositories.Abstract;
using OrderServiceApiii.Entity.Concrete.Buyer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApiii.DataAccess.Repositories
{
    public class BuyerRepository : GenericRepository<Buyer>, IBuyerRepository
    {
        public BuyerRepository(OrderContext orderContext) : base(orderContext)
        {

        }
    }
}

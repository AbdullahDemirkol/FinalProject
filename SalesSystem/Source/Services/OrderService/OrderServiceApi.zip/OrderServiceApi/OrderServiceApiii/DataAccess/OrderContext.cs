﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using OrderServiceApiii.DataAccess.EntityConfigurations;
using OrderServiceApiii.Entity.Abstract;
using OrderServiceApiii.Entity.Concrete.Buyer;
using OrderServiceApiii.Entity.Concrete.Helper.Enum;
using OrderServiceApiii.Entity.Concrete.Order;
using OrderServiceApiii.Extensions.BussExtension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OrderServiceApiii.DataAccess
{
    public class OrderContext : DbContext, IUnitOfWork
    {
        public const string DEFAULT_SCHEMA = "ordering";
        private readonly IMediator _mediator;
        public OrderContext() : base()
        {

        }
        public OrderContext(DbContextOptions<OrderContext> options, IMediator mediator) : base(options)
        {
            _mediator = mediator;

        }

        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<PaymentMethod> PaymentMethods { get; set; }
        public DbSet<Buyer> Buyers { get; set; }
        public DbSet<CardType> CardTypes { get; set; }
        public DbSet<OrderStatus> OrderStatus { get; set; }

        public async Task<bool> SaveEntityAsync(CancellationToken cancellationToken = default)
        {
            await _mediator.DispatchDomainEventsAsnyc(this);
            await base.SaveChangesAsync(cancellationToken);
            return true;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new OrderEntityConfiguration());
            modelBuilder.ApplyConfiguration(new BuyerEntityConfiguration());
            modelBuilder.ApplyConfiguration(new CardTypeEntityConfiguration());
            modelBuilder.ApplyConfiguration(new OrderItemEntityConfiguration());
            modelBuilder.ApplyConfiguration(new OrderStatusEntityConfiguration());
            modelBuilder.ApplyConfiguration(new PaymentMethodEntityConfiguration());
        }
    }
}

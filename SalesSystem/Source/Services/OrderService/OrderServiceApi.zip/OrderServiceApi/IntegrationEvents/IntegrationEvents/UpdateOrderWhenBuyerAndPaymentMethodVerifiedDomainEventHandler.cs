﻿using OrderServiceApi.DataAccess.Abstract;
using OrderServiceApi.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OrderServiceApi.IntegrationEvents.IntegrationEvents
{
    public class UpdateOrderWhenBuyerAndPaymentMethodVerifiedDomainEventHandler
    {
        private readonly IOrderRepository _orderRepository;

        public UpdateOrderWhenBuyerAndPaymentMethodVerifiedDomainEventHandler(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository ?? throw new ArgumentNullException(nameof(orderRepository));
        }

        public async Task Handle(BuyerAndPaymentMethodVerifiedModel buyerAndPaymentMethodVerifiedDomainEvent, CancellationToken cancellationToken)
        {
            var orderToUpdate = await _orderRepository.GetByIdAsync(buyerAndPaymentMethodVerifiedDomainEvent.OrderId);
            orderToUpdate.SetBuyerId(buyerAndPaymentMethodVerifiedDomainEvent.Buyer.Id);
            orderToUpdate.SetPaymentMethodId(buyerAndPaymentMethodVerifiedDomainEvent.Payment.Id);
            //set methods so validate
        }
    }
}

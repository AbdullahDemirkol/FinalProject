﻿using EventBus.Base.Entity.Abstract;
using EventBus.Base.EventBus.Abstract;
using OrderServiceApi.DataAccess.Abstract;
using OrderServiceApi.Entity.Concrete.Buyer;
using OrderServiceApi.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OrderServiceApi.IntegrationEvents.IntegrationEvents
{
    public class OrderStartedModelHandler : IIntegrationEventHandler<OrderStartedDomainModel>
    {
        private readonly IBuyerRepository _buyerRepository;
        private readonly IEventBus _eventBus;

        public OrderStartedModelHandler(IBuyerRepository buyerRepository,IEventBus eventBus)
        {
            _buyerRepository = buyerRepository;
            _eventBus = eventBus;
        }

        public async Task Handle(OrderStartedDomainModel OrderStartedModel)
        {
            var cardTypeId = (OrderStartedModel.CardTypeId != 0) ? OrderStartedModel.CardTypeId : 1;
            var buyer = await _buyerRepository.GetSingleAsync(i => i.Name == OrderStartedModel.UserName, i => i.PaymentMethods());
            bool buyerOriginallyExisted = buyer != null;
            if (!buyerOriginallyExisted)
            {
                buyer = new Buyer(OrderStartedModel.UserName);
            }
            buyer.VerifyOrAddPaymentMethod(cardTypeId, $"Ödeme yöntemi {DateTime.UtcNow}", OrderStartedModel.CardNumber, OrderStartedModel.CardSecurityNumber, OrderStartedModel.CardHolderName, OrderStartedModel.CardExpiration, OrderStartedModel.Order.Id);
            var buyerUpdated = buyerOriginallyExisted ? _buyerRepository.Update(buyer) : await _buyerRepository.AddAsync(buyer);
            await _buyerRepository.SaveEntityAsync(_eventBus);
        }

    }
}

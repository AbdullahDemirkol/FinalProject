﻿using EventBus.Base.Entity.Abstract;
using EventBus.Base.EventBus.Abstract;
using Microsoft.Extensions.Logging;
using OrderServiceApi.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.IntegrationEvents.IntegrationEvents
{
    public class OrderCreatedIntegrationEventHandler : IIntegrationEventHandler<OrderCreatedModel>
    {
        private readonly ILogger<OrderCreatedIntegrationEventHandler> _logger;
        private readonly IEventBus _eventBus;

        public OrderCreatedIntegrationEventHandler(ILogger<OrderCreatedIntegrationEventHandler> logger, IEventBus eventBus)
        {
            _logger = logger;
            _eventBus = eventBus;
        }

        public async Task Handle(OrderCreatedModel integrationEvent)
        {
            _logger.LogInformation("Handling integration event:{IntegrationEventId} at {AppName}-({IntegrationEvent})", integrationEvent.Id, typeof(Startup).Namespace, integrationEvent);
            var createOrderCommand = new CreateOrderModel(integrationEvent.Basket.Items, integrationEvent.UserId, integrationEvent.UserName, integrationEvent.City, integrationEvent.Street, integrationEvent.State, integrationEvent.Country, integrationEvent.ZipCode, integrationEvent.CardNumber, integrationEvent.CardHolderName, integrationEvent.CardExpiration, integrationEvent.CardSecurityNumber, integrationEvent.CardTypeId);
            _eventBus.Publish(createOrderCommand); 

        }
    }
}

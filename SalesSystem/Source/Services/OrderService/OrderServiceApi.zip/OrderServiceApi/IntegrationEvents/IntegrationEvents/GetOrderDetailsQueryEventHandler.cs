﻿using OrderServiceApi.DataAccess.Abstract;
using OrderServiceApi.Entity.Concrete.Order;
using OrderServiceApi.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OrderServiceApi.IntegrationEvents.IntegrationEvents
{
    public class GetOrderDetailsQueryEventHandler 
    {
        IOrderRepository orderRepository;

        public GetOrderDetailsQueryEventHandler(IOrderRepository orderRepository)
        {
            this.orderRepository = orderRepository ?? throw new ArgumentNullException(nameof(orderRepository));
        }

        public async Task<Order> Handle(GetOrderDetailsQueryModel request, CancellationToken cancellationToken)
        {
            var order = await orderRepository.GetByIdAsync(request.OrderId, i => i.OrderItems());

            return order;
        }
    }
}

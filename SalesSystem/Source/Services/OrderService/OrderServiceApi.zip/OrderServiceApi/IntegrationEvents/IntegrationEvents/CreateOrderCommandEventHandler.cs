﻿using EventBus.Base.EventBus.Abstract;
using OrderServiceApi.DataAccess.Abstract;
using OrderServiceApi.Entity.Concrete.Order;
using OrderServiceApi.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OrderServiceApi.IntegrationEvents.IntegrationEvents
{
    public class CreateOrderCommandHandler 
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IEventBus _eventBus;

        public CreateOrderCommandHandler(IOrderRepository orderRepository, IEventBus eventBus)
        {
            _orderRepository = orderRepository;
            _eventBus = eventBus;
        }
        public async Task<bool> Handle(CreateOrderModel request, CancellationToken cancellationToken)
        {
            var addr = new Address(request.Street, request.City, request.State, request.Country, request.ZipCode);
            Order dbOrder = new(request.UserName, request.CardTypeId, request.CardNumber, request.CardSecurityNumber, request.CardHolderName, request.CardExpiration, addr, null);
            request.OrderItems.ToList().ForEach(i => dbOrder.AddOrderItem(i.ProductId, i.ProductName, i.UnitPrice, i.PictureUrl, i.Units));
            await _orderRepository.AddAsync(dbOrder);
            await _orderRepository.SaveEntityAsync(_eventBus);
            var orderStartedIntegrationEvent = new OrderStartedDomainModel(request.UserName);
            _eventBus.Publish(orderStartedIntegrationEvent);
            return true;

        }
    }
}

﻿using EventBus.Base.Entity.Concrete;
using OrderServiceApi.Entity.Concrete;
using OrderServiceApi.Entity.Concrete.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderServiceApi.IntegrationEvents.Events
{
    public class CreateOrderModel : IntegrationEvent
    {
        private readonly List<OrderItem> _orderItems;

        public string UserName { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string ZipCode { get; set; }
        public string CardNumber { get; set; }
        public string CardHolderName { get; set; }
        public DateTime CardExpiration { get; set; }
        public string CardSecurityNumber { get; set; }
        public int CardTypeId { get; set; }
        public IEnumerable<OrderItem> OrderItems => _orderItems;
        public string CorrelationId { get; set; }

        public CreateOrderModel()
        {
            _orderItems = new List<OrderItem>();
        }

        public CreateOrderModel(List<BasketItem> basketItems, string userId, string userName, string city, string street, string state, string country, string zipCode, string cardNumber, string cardHolderName, DateTime cardExpiration, string cardSecurityNumber, int cardTypeId) : this()
        {
            var dtoList = basketItems.Select(item => new OrderItem(item.ProductId, item.ProductName,item.PictureUrl,item.UnitPrice,item.Quantity));


            _orderItems = dtoList.ToList();

            UserName = userName;
            City = city;
            Street = street;
            State = state;
            Country = country;
            ZipCode = zipCode;
            CardNumber = cardNumber;
            CardHolderName = cardHolderName;
            CardExpiration = cardExpiration;
            CardSecurityNumber = cardSecurityNumber;
            CardTypeId = cardTypeId;
        }
    }
}

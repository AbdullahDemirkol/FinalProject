﻿using EventBus.Base.EventBus.Abstract;
using Microsoft.Extensions.DependencyInjection;
using NotificationService.Configuration;
using NotificationService.IntegrationEvents.EventHandlers;
using NotificationService.IntegrationEvents.Events;
using System;

namespace NotificationServiceConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceCollection services = new ServiceCollection();
            ConfigureServices(services);

            var serviceProvider = services.BuildServiceProvider();
            IEventBus eventBus = serviceProvider.GetRequiredService<IEventBus>();

            eventBus.Subscribe<OrderPaymentFailedModel, OrderPaymentFailedIntegrationEventHandler>();
            eventBus.Subscribe<OrderPaymentSuccessModel, OrderPaymentSuccessIntegrationEventHandler>();




            Console.WriteLine("Application is Running...");
            Console.ReadLine();
        }

        private static void ConfigureServices(IServiceCollection services)
        {

            //services.AddLogging(configure => configure.AddConsole());
            services.AddTransient<OrderPaymentSuccessIntegrationEventHandler>();
            services.AddTransient<OrderPaymentFailedIntegrationEventHandler>();

            services.ConfigureServiceEventBus();

        }
    }
}

﻿using EventBus.Base.Entity.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotificationService.IntegrationEvents.Events
{
    public class OrderPaymentSuccessModel : IntegrationEvent
    {
        public int OrderId;
        public string SuccessMessage;

        public OrderPaymentSuccessModel(int orderId, string successMessage)
        {
            OrderId = orderId;
            SuccessMessage = successMessage;
        }
    }
}
